let img = document.createElement('img');
img.src = 'https://th.bing.com/th/id/R.f59823049f9f756cd1035cdba478ac4d?rik=%2fMNSHCconXT1Dw&riu=http%3a%2f%2fimages1.wikia.nocookie.net%2f__cb20100604223617%2fshrek%2fimages%2f8%2f87%2fShrek_fierce.jpg&ehk=p8zy9cnNuydXaZYliSW4hluZutiZ6nUTQkQEq28%2fTvg%3d&risl=&pid=ImgRaw&r=0';
img.style.position = 'fixed';
img.style.top = 0;
img.style.left = 0;
img.style.width = '100%';
img.style.height = '100%';
img.style.zIndex = 999999;
document.body.appendChild(img);
